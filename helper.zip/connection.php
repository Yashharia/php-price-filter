<?php
// $user = 'mumbatsm_admin';
// $pass = ';~u@1lXdF?()';
$user = 'root';
$pass = '';
$db = 'php_price_filter';
$mysqli = new mysqli('localhost', $user, $pass, $db) or die("unable");

#$user='bdabonli_yash';
#$pass='kK}O.;^%El$j';

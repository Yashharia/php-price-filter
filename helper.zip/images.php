<?php include 'header.php'; ?>
<div class="container text-center">
  <div class="row row-cols-2 row-cols-lg-5 g-2 g-lg-3">
    <div class="col">
      <div class="p-3"><img src="" alt=""></div>
    </div>
    <div class="col">
      <div class="p-3"><img src="" alt=""></div>
    </div>
    <div class="col">
      <div class="p-3"><img src="" alt=""></div>
    </div>
    <div class="col">
      <div class="p-3"><img src="" alt=""></div>
    </div>
    <div class="col">
      <div class="p-3"><img src="" alt=""></div>
    </div>
    <div class="col">
      <div class="p-3"><img src=""/></div>
    </div>
    <div class="col">
      <div class="p-3"><img src=""/></div>
    </div>
    <div class="col">
      <div class="p-3"><img src=""/></div>
    </div>
    <div class="col">
      <div class="p-3"><img src=""/></div>
    </div>
    <div class="col">
      <div class="p-3"><img src=""/></div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>